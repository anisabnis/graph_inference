f = open('out.txt', 'r')
for l in f:
    l = l.strip().split(' ')
    print(len(l))
